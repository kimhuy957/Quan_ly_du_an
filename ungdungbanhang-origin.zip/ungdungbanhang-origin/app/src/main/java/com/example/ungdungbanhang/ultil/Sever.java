package com.example.ungdungbanhang.ultil;

public class Sever {
    public static String localhost = "192.168.110.134";
    public static String duongDanLoaiSP = "https://" + localhost + ":8888/Server/getloaisp.php";
    public static String duongDanSPMoiNhat = "https://" + localhost + ":8888/Server/getsanphammoinhat.php";
}
